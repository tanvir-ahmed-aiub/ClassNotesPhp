<?php
    function index()
    {
        //echo "OK";
        header('Location:'. '../views/index.php');
        //include "views/index.php";
    }
    index();
?>