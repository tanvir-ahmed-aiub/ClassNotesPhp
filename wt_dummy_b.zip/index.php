<?php
    header ('Location:'.'controllers/HomeController.php');
?>